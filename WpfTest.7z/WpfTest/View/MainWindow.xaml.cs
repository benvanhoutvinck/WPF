﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfTest.Model;
using WpfTest.ViewModel;

namespace WpfTest
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Dictionary<SolidColorBrush, Kleur> kleurkes;
        public MainWindow()
        {
            kleurkes = new Dictionary<SolidColorBrush, Kleur>();
            InitializeComponent();
            foreach (PropertyInfo info in typeof(Colors).GetProperties())
            {
                BrushConverter bc = new BrushConverter();
                SolidColorBrush deKleur =
                (SolidColorBrush)bc.ConvertFromString(info.Name);
                Kleur kleurke = new Kleur();
                kleurke.Borstel = deKleur;
                kleurke.Naam = info.Name;
                kleurke.Hex = deKleur.ToString();
                kleurke.Rood = deKleur.Color.R;
                kleurke.Groen = deKleur.Color.G;
                kleurke.Blauw = deKleur.Color.B;
                comboBoxKleuren.Items.Add(kleurke);
                if (kleurke.Naam == "Black")
                    comboBoxKleuren.SelectedItem = kleurke;
                //kleurkes.Add(deKleur, kleurke);
            }
        }

        private Ellipse sleepEllipse = new Ellipse();
        private void voorbeeld_MouseMove(object sender, MouseEventArgs e)
        {
            sleepEllipse = (Ellipse)sender;
            if ((e.LeftButton == MouseButtonState.Pressed) && (sleepEllipse.Fill != Brushes.White))
            {
                DataObject sleepKleur = new DataObject("deKleur", sleepEllipse.Fill);
                DragDrop.DoDragDrop(sleepEllipse, sleepKleur, DragDropEffects.Move);
            }
        }

        private void Canvas_DragEnter(object sender, DragEventArgs e)
        {

        }

        private void Canvas_DragLeave(object sender, DragEventArgs e)
        {

        }

        private void Canvas_DragOver(object sender, DragEventArgs e)
        {

        }

        private void Canvas_Drop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent("deKleur"))
            {
                
                SolidColorBrush gesleepteKleur = (SolidColorBrush)e.Data.GetData("deKleur");
                Point positie = e.GetPosition(Canvaske);
                ((WenskaartVM)this.DataContext).DoDrop(gesleepteKleur, positie.X, positie.Y);
            }
        }
    }
}
