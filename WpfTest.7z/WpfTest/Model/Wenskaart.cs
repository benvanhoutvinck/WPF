﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfTest.Model
{
    class Wenskaart
    {
        public string Wens { get; set; }

        public List<Bal> Ballen { get; set; }

        public Wenskaart()
        {
            this.Ballen = new List<Bal>();
        }
    }
}
