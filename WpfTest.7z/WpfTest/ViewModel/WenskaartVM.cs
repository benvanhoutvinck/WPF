﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using WpfTest.Model;

namespace WpfTest.ViewModel
{
    class WenskaartVM : ViewModelBase
    {
        private Wenskaart wenskaart;

        public WenskaartVM(Wenskaart wenskaart)
        {
           
            this.wenskaart = wenskaart;
            Bal bal = new Bal((SolidColorBrush)(new BrushConverter().ConvertFrom("#ffaacc")), 150, 150);
            //Ballen.Add(bal);
            BalToevoegen(bal);
        }

        public List<Bal> Ballen
        {
            get { return wenskaart.Ballen;  }
            set { wenskaart.Ballen = value;
            RaisePropertyChanged("Ballen");
            }
        }

        public void BalToevoegen(Bal bal)
        {
            Ballen.Add(bal);
            RaisePropertyChanged("Ballen");
        }

        public void DoDrop(SolidColorBrush kleur, double x, double y)
        {
            Bal nieuweBal = new Bal(kleur, (int)x, (int)y);
            BalToevoegen(nieuweBal);
        }

       
        public RelayCommand<DragEventArgs> DropCommand
        {
            get { return new RelayCommand<DragEventArgs>(OnDrop); }
        }

        public void OnDrop(DragEventArgs e)
        {
            Bal nieuweBal = new Bal(kleur, e.GetPosition(e.Source).X, e.GetPosition().Y);
        }
    }
}
